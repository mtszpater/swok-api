create function get_all_talks_count(text) returns bigint
LANGUAGE SQL
AS $$
select count(*) from talk WHERE event_name = $1;
$$;
