create function get_all_members_of_the_event(numeric) returns bigint
LANGUAGE SQL
AS $$
select count(*) from subscriptions WHERE talk_id = $1;
$$;
