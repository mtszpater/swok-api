create function update_all_events_members() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
      UPDATE talk SET members = (Select * from get_all_events_members(talk.id));
      return new;
    END;
$$;
