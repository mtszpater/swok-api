create function add(numeric) returns bigint
LANGUAGE SQL
AS $$
select count(*) from subscriptions WHERE talk_id = $1;
$$;
