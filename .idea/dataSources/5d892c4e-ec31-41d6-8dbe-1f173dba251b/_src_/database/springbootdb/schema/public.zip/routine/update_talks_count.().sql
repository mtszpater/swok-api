create function update_talks_count() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
      UPDATE event SET talks = (Select * from get_all_talks_count(event.name));
      return new;
    END;
$$;
