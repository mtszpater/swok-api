create function get_all_events_members(numeric) returns bigint
LANGUAGE SQL
AS $$
select count(*) from attendance_on_talks WHERE talk_id = $1;
$$;
